if not rq then rq = {} end
rq.big_icons = {}

data:extend(
{
	{
		type = "custom-input",
		name = "open-research-queue",
		key_sequence = "CONTROL +T ",
	}
})