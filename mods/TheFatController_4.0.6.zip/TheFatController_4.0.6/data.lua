require("__TheFatController__/prototypes/fatcontroller")
require("__TheFatController__/prototypes/style")