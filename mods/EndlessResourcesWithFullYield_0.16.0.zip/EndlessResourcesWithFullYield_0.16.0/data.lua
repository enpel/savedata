for k, v in pairs(data.raw.resource) do
   data.raw.resource[k].infinite = true
   data.raw.resource[k].minimum  = 100
   data.raw.resource[k].normal   = 100
end