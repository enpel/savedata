local CategoryMainController = {
  classname = "FNCategoryMainController",
}

local cont_gui

function CategoryMainController.init_event(gui_name, content_gui)
  cont_gui = content_gui
end

function CategoryMainController.draw_content()
  
end

return CategoryMainController