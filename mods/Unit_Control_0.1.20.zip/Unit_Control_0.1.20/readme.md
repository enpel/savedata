## Unit Control

--------------------------------------

Allows controlling units with special 'Unit selection tool' and other tools available through the GUI.
