data:extend(
{
  {
    type = "bool-setting",
    name = "bobmods-vehicleequipment-enablevehiclegrids",
    setting_type = "startup",
    default_value = true,
    per_user = false,
  },
}
)



