table.insert(
  data.raw["technology"]["oil-processing"].effects,
  {type = "unlock-recipe",recipe = "flare-stack"})
table.insert(
  data.raw["technology"]["oil-processing"].effects,
  {type = "unlock-recipe",recipe = "vent-stack"})
table.insert(
  data.raw["technology"]["advanced-material-processing"].effects,
  {type = "unlock-recipe",recipe = "electric-incinerator"})