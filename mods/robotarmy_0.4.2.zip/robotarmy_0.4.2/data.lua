require("config.config")
require("prototypes.droid-animations")
require("prototypes.item") -- any buildable or placable object/entity needs this 
require("prototypes.building")
require("prototypes.entity") -- any buildable or placable object/entity needs this
require("prototypes.recipe")
require("prototypes.signals")
require("prototypes.projectiles.projectiles")
require("prototypes.corpses")
require("prototypes.destroyer-unit")
require("prototypes.distractor-unit")
require("prototypes.defender-unit")


--require("prototypes.DroidUnitList")



